#include "common.h"

struct point_light
{
	color intensity;
	point3 position;
};